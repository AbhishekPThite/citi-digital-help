define(['./_shallowProperty'], function (_shallowProperty) {

	// Internal helper to obtain the `length` property of an object.
	var getLength = _shallowProperty('length');

	return getLength;

});
