define(['./_tagTester'], function (_tagTester) {

	var isNumber = _tagTester('Number');

	return isNumber;

});
