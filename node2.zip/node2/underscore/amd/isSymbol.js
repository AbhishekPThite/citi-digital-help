define(['./_tagTester'], function (_tagTester) {

	var isSymbol = _tagTester('Symbol');

	return isSymbol;

});
